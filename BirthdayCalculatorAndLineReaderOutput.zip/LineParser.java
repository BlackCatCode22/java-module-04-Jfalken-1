import java.util.ArrayList;

public class LineParser {
    public static void parseLine(String line) {
        ArrayList<String> animalAttributes = new ArrayList<>();

        String[] sections = line.split(",");
        String[] section1 = sections[0].split(" ");

        // Age, sex and species.
        String age = section1[0];
        String sex = section1[3];
        String species = section1[4];

        String[] section2 = sections[1].split(" ");

        // Season born
        String seasonBorn = section2[3];

        // Color
        String color = sections[2].substring(0, sections[2].indexOf("color"));

        // Weight
        String weight = sections[3];

        // Origen
        String origen = sections[4].substring(6) + "," + sections[5];

        System.out.println(
                "\nAge: " + age + "\n" +
                        "Sex: " + sex + "\n" +
                        "Species: " + species + "\n" +
                        "Season born: " + seasonBorn + "\n" +
                        "Color: " + color + "\n" +
                        "Weight: " + weight + "\n" +
                        "Origen: " + origen + "\n\n"
        );

    }
}
