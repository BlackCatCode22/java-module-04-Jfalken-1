public class FindYearAndSeason {
    public static int findAge (String animalLine) {

        String[] splitByComma = animalLine.split(",");
        String[] seaction1SplitBySpace = splitByComma[0].split(" ");

       return Integer.parseInt(seaction1SplitBySpace[0]);
    }

    public static String findSeason (String animalLine) {
        String[] splitByComma = animalLine.split(",");
        String[] section2SplitBySpace = splitByComma[1].split(" ");

        return section2SplitBySpace[3];
    }

}
