// JF 2024-10-01
// TodaysDate.Java

import java.time.LocalDate;
import java.util.Date;
import java.text.SimpleDateFormat;

public class TodaysDate {
    public static void main(String[] args) {
        System.out.println("\nWelcome to dates and Animal Class\n");

        int year = 2024;
        int month;
        int day = 1;

        LocalDate date = LocalDate.of(2024, 10, 1);


        // Calculate birthdays for the following two hyenas.
        String hyena1 = "4 year old female hyena, born in spring, tan color, 70 pounds, from Friguia Park, Tunisia";
        String hyena2 = "12 year old male hyena, born in fall, brown color, 150 pounds, from Friguia Park, Tunisia";


        int hyena1Age = FindYearAndSeason.findAge(hyena1);
        String hyena1Season = FindYearAndSeason.findSeason(hyena1);

        int hyena2Age = FindYearAndSeason.findAge(hyena2);
        String hyena2Season = FindYearAndSeason.findSeason(hyena2);

        LocalDate hyena1Birthday = BirthdayCalculator.calculateBirthday(hyena1Age, hyena1Season);
        LocalDate hyena2Birthday = BirthdayCalculator.calculateBirthday(hyena2Age, hyena2Season);

        System.out.println(hyena1Birthday);
        System.out.println(hyena2Birthday);






    }
}