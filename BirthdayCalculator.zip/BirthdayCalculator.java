import java.time.LocalDate;

public class BirthdayCalculator {


    public static LocalDate calculateBirthday(int year, String season) {
        int currentYear = LocalDate.now().getYear();

        int birthYear = currentYear - year;

        int birthMonth = switch (season.toLowerCase()) {
            case "spring" -> 3;
            case "fall" -> 9;
            default -> 0;
        };



        return LocalDate.of(birthYear, birthMonth, 1);
    }
}
