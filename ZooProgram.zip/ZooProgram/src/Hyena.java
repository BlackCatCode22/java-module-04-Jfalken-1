//package jacob.zoo.com;
public class Hyena extends Animal {

    private static int numOfHyenas;

    // Hyena constructor
    public Hyena(String name) {
        super(name);
        numOfHyenas++;
    }

    public static int getNumOfHyenas() {
        return numOfHyenas;
    }
}
