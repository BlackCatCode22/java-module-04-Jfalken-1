//package jacob.zoo.com;

// JF
// 9/26/2024
// Driver file for the zoo midterm program.

public class App {
    public static void main(String[] args) {
        System.out.println("Welcome to my ZooProgram!");
        System.out.println("\nThe number of animals is: " + Animal.getNumOfAnimals());

        Animal animal = new Animal("Jeff");
        System.out.println("\nThis animals name is: " + animal.getAnimalName() + "!");
        System.out.println("\nThe number of animals is now: " + Animal.getNumOfAnimals());

        animal.setAnimalName("Jefff");
        System.out.println("\nNow it's name is " + animal.getAnimalName());

        System.out.println("\nThere are " + Hyena.getNumOfHyenas() + " hyenas.");

        Hyena hyena = new Hyena("Hank");
        System.out.println("\nThe name of this hyena is " + hyena.getAnimalName());

        System.out.println("\nThe number of hyenas is now " + Hyena.getNumOfHyenas());

        System.out.println("\nThere are now " + Animal.getNumOfAnimals() + " animals.");
    }
}