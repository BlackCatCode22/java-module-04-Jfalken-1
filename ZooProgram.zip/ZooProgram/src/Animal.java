//package jacob.zoo.com;
import java.util.Date;

public class Animal {

    // Attributes (fields)
    private String animalName;
    private int age;
    private String sex;
    private String weight;
    private String color;
    private String animalID;
    private Date animalBirthdate;
    private String origen;
    private Date arrivalDate;
    private static int numOfAnimals;

    // Animal constructor
//    public Animal(int age, String sex, String wight, String animalID, String animalName, Date animalBirthdate, String color, String origen, Date arrivalDate) {
//        this.age = age;
//        this.sex = sex;
//        this.weight = wight;
//        this.animalID = animalID;
//        this.animalName = animalName; // names will come from txt file called animalNames
//        this.animalBirthdate = animalBirthdate;
//        this.color = color;
//        this.origen = origen;
//        this.arrivalDate = arrivalDate;
//        numOfAnimals++;
//    }

    // constructor that accepts name
    public Animal(String animalName) {
        this.animalName = animalName;
        numOfAnimals++;
        System.out.println("\nAn animal was made!");
    }

    // Getters
    public int getAge() {
        return age;
    }

    public String getSex() {
        return sex;
    }

    public String getAnimalID() {
        return animalID;
    }

    public String getWeight() {
        return weight;
    }

    public String getAnimalName() {
        return animalName;
    }

    public Date getAnimalBirthdate() {
        return animalBirthdate;
    }

    public String getColor() {
        return color;
    }

    public String getOrigen() {
        return origen;
    }

    public Date getArrivalDate() {
        return arrivalDate;
    }

    public static int getNumOfAnimals() {
        return numOfAnimals;
    }

    // Setters
    public void setAge(int age) {
        this.age = age;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setAnimalID(String animalID) {
        this.animalID = animalID;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public void setAnimalBirthdate(Date animalBirthdate) {
        this.animalBirthdate = animalBirthdate;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setArrivalDate(Date arrivalDate) {
        this.arrivalDate = arrivalDate;
    }
}
